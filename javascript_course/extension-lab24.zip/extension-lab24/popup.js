function displayData(data) {
  var message = "City: " + data.current_observation.display_location.full + " " + data.current_observation.display_location.zip + "<br/>";
  message += "Current Temperature: " + data.current_observation.temperature_string +" "+data.current_observation.weather + "<br/>";
  message += "Feels like: " + data.current_observation.feelslike_string + "<br/>";
  message += "Humidity: " + data.current_observation.relative_humidity + "<br/>";
  message += "Wind: " + data.current_observation.wind_string + "<br/><br/>";
  message +=  data.current_observation.forecast_url;
  $("#info").html(message);
}
$(document).ready(function() {
  $("#btn").click(function(){
    $("#info").html("Getting information...");
    var code = $("#city").val();
    $.get("http://api.wunderground.com/api/e069d13c9432ad2f/conditions/q/CA/" + code + ".json", '',
    function(data){
      displayData(data);
    });
  });
});
